<?php

/**
 * History actions.
 *
 * @package    robo_test
 * @subpackage History
 * @author     MDG
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class HistoryActions extends sfActions
{
  public function executeIndex(sfWebRequest $request)
  {
    $this->hists = Doctrine_Core::getTable('Hist')
      ->createQuery('a')
      ->execute();
  }

  public function executeShow(sfWebRequest $request)
  {
    $this->hist = Doctrine_Core::getTable('Hist')->find(array($request->getParameter('id')));
    $this->forward404Unless($this->hist);
  }

  public function executeNew(sfWebRequest $request)
  {
    $this->form = new HistForm();
  }

  public function executeCreate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod(sfRequest::POST));

    $this->form = new HistForm();

    $this->processForm($request, $this->form);

    $this->setTemplate('new');
  }

  public function executeEdit(sfWebRequest $request)
  {
    $this->forward404Unless($hist = Doctrine_Core::getTable('Hist')->find(array($request->getParameter('id'))), sprintf('Object hist does not exist (%s).', $request->getParameter('id')));
    $this->form = new HistForm($hist);
  }

  public function executeUpdate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod(sfRequest::POST) || $request->isMethod(sfRequest::PUT));
    $this->forward404Unless($hist = Doctrine_Core::getTable('Hist')->find(array($request->getParameter('id'))), sprintf('Object hist does not exist (%s).', $request->getParameter('id')));
    $this->form = new HistForm($hist);

    $this->processForm($request, $this->form);

    $this->setTemplate('edit');
  }

  public function executeDelete(sfWebRequest $request)
  {
    $request->checkCSRFProtection();

    $this->forward404Unless($hist = Doctrine_Core::getTable('Hist')->find(array($request->getParameter('id'))), sprintf('Object hist does not exist (%s).', $request->getParameter('id')));
    $hist->delete();

    $this->redirect('History/index');
  }

  protected function processForm(sfWebRequest $request, sfForm $form)
  {
    $form->bind($request->getParameter($form->getName()), $request->getFiles($form->getName()));
    if ($form->isValid())
    {
      $hist = $form->save();

      $this->redirect('History/edit?id='.$hist->getId());
    }
  }
}
