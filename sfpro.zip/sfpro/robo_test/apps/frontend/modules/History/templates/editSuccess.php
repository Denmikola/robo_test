<h1>Edit Hist</h1>

<?php include_partial('form', array('form' => $form)) ?>
