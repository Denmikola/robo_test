<h1>Hists List</h1>

<table>
  <thead>
    <tr>
      <th>Id</th>
      <th>Pers</th>
      <th>Don</th>
      <th>Sum</th>
      <th>Bal in</th>
      <th>Bal out</th>
      <th>T plan</th>
      <th>T rel</th>
      <th>Is rel</th>
      <th>Created at</th>
      <th>Updated at</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($hists as $hist): ?>
    <tr>
      <td><a href="<?php echo url_for('History/show?id='.$hist->getId()) ?>"><?php echo $hist->getId() ?></a></td>
      <td><?php echo $hist->getPersId() ?></td>
      <td><?php echo $hist->getDonId() ?></td>
      <td><?php echo $hist->getSum() ?></td>
      <td><?php echo $hist->getBalIn() ?></td>
      <td><?php echo $hist->getBalOut() ?></td>
      <td><?php echo $hist->getTPlan() ?></td>
      <td><?php echo $hist->getTRel() ?></td>
      <td><?php echo $hist->getIsRel() ?></td>
      <td><?php echo $hist->getCreatedAt() ?></td>
      <td><?php echo $hist->getUpdatedAt() ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

  <a href="<?php echo url_for('History/new') ?>">New</a>
