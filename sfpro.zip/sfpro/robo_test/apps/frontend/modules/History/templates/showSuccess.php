<table>
  <tbody>
    <tr>
      <th>Id:</th>
      <td><?php echo $hist->getId() ?></td>
    </tr>
    <tr>
      <th>Pers:</th>
      <td><?php echo $hist->getPersId() ?></td>
    </tr>
    <tr>
      <th>Don:</th>
      <td><?php echo $hist->getDonId() ?></td>
    </tr>
    <tr>
      <th>Sum:</th>
      <td><?php echo $hist->getSum() ?></td>
    </tr>
    <tr>
      <th>Bal in:</th>
      <td><?php echo $hist->getBalIn() ?></td>
    </tr>
    <tr>
      <th>Bal out:</th>
      <td><?php echo $hist->getBalOut() ?></td>
    </tr>
    <tr>
      <th>T plan:</th>
      <td><?php echo $hist->getTPlan() ?></td>
    </tr>
    <tr>
      <th>T rel:</th>
      <td><?php echo $hist->getTRel() ?></td>
    </tr>
    <tr>
      <th>Is rel:</th>
      <td><?php echo $hist->getIsRel() ?></td>
    </tr>
    <tr>
      <th>Created at:</th>
      <td><?php echo $hist->getCreatedAt() ?></td>
    </tr>
    <tr>
      <th>Updated at:</th>
      <td><?php echo $hist->getUpdatedAt() ?></td>
    </tr>
  </tbody>
</table>

<hr />

<a href="<?php echo url_for('History/edit?id='.$hist->getId()) ?>">Edit</a>
&nbsp;
<a href="<?php echo url_for('History/index') ?>">List</a>
