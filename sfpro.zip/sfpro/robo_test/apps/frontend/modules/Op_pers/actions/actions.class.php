<?php

/**
 * Op_pers actions.
 *
 * @package    robo_test
 * @subpackage Op_pers
 * @author     MDG
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class Op_persActions extends sfActions
{
  public function executeIndex(sfWebRequest $request)
  {
    $this->perss = Doctrine_Core::getTable('Pers')->getClientList();
    $this->perevods = Doctrine_Core::getTable('Perevod')->getAllPerevod(); 
  }

  public function executeShow(sfWebRequest $request)
  {
    $this->pers = Doctrine_Core::getTable('Pers')->find(array($request->getParameter('id')));
    $this->forward404Unless($this->pers);
  }

  public function executeNew(sfWebRequest $request)
  {
    $this->form = new PersForm();
  }

  public function executeCreate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod(sfRequest::POST));

    $this->form = new PersForm();

    $this->processForm($request, $this->form);

    $this->setTemplate('new');
  }

  public function executeEdit(sfWebRequest $request)
  {
    $this->forward404Unless($pers = Doctrine_Core::getTable('Pers')->find(array($request->getParameter('id'))), sprintf('Object pers does not exist (%s).', $request->getParameter('id')));
    $this->form = new PersForm($pers);
  }

  public function executeUpdate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod(sfRequest::POST) || $request->isMethod(sfRequest::PUT));
    $this->forward404Unless($pers = Doctrine_Core::getTable('Pers')->find(array($request->getParameter('id'))), sprintf('Object pers does not exist (%s).', $request->getParameter('id')));
    $this->form = new PersForm($pers);

    $this->processForm($request, $this->form);

    $this->setTemplate('edit');
  }

  public function executeDoPerevod(sfWebRequest $request)
  {

    $wper = Doctrine_Core::getTable('Perevod')->getPerevodforNow();
    if ($wper->count() > 0)
      foreach ($wper as $wp):
        Doctrine_Core::getTable('Hist')->MakePerevodHist($wp->getPayer_id(),$wp->getResiv_id(),$wp->getSum(),$wp->getTimeplan());
        Doctrine_Core::getTable('Pers')->MakePerevodPers($wp->getPayer_id(),$wp->getResiv_id(),$wp->getSum());
        Doctrine_Core::getTable('Perevod')->MakePerevod($wp->getId());
      endforeach;
     $this->redirect('Op_pers/index');
     }

  public function executePlanPerevod(sfWebRequest $request)
  {
    
    $swper = Doctrine_Core::getTable('Perevod')->getSumPerevodById($request);
    $sbal = Doctrine_Core::getTable('Pers')->getBalanceById($request);
    $sp=$request->getParameter('Sum_per');
    if($sbal-$swper-$sp<0) printf('No money!!!');
    else 
      Doctrine_Core::getTable('Perevod')->AddPerevod($request);
    $this->redirect('Op_pers/index');
  }

  public function executeDelete(sfWebRequest $request)
  {
    $request->checkCSRFProtection();

    $this->forward404Unless($pers = Doctrine_Core::getTable('Pers')->find(array($request->getParameter('id'))), sprintf('Object pers does not exist (%s).', $request->getParameter('id')));
    $pers->delete();

    $this->redirect('Op_pers/index');
  }

  protected function processForm(sfWebRequest $request, sfForm $form)
  {
    $form->bind($request->getParameter($form->getName()), $request->getFiles($form->getName()));
    if ($form->isValid())
    {
      $pers = $form->save();

      $this->redirect('Op_pers/edit?id='.$pers->getId());
    }
  }
}
