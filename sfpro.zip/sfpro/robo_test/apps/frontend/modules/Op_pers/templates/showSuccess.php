<table>
  <tbody>
    <tr>
      <th>Id:</th>
      <td><?php echo $pers->getId() ?></td>
    </tr>
    <tr>
      <th>Fam:</th>
      <td><?php echo $pers->getFam() ?></td>
    </tr>
    <tr>
      <th>Name:</th>
      <td><?php echo $pers->getName() ?></td>
    </tr>
    <tr>
      <th>Otch:</th>
      <td><?php echo $pers->getOtch() ?></td>
    </tr>
    <tr>
      <th>Bal:</th>
      <td><?php echo $pers->getBal() ?></td>
    </tr>
  </tbody>
</table>

<hr />

<a href="<?php echo url_for('Op_pers/edit?id='.$pers->getId()) ?>">Edit</a>
&nbsp;
<a href="<?php echo url_for('Op_pers/index') ?>">List</a>
