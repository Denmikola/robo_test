<?php

/**
 * Perevod form base class.
 *
 * @method Perevod getObject() Returns the current form's model object
 *
 * @package    robo_test
 * @subpackage form
 * @author     MDG
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BasePerevodForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'         => new sfWidgetFormInputHidden(),
      'payer_id'   => new sfWidgetFormInputText(),
      'resiv_id'   => new sfWidgetFormInputText(),
      'sum'        => new sfWidgetFormInputText(),
      'timeplan'   => new sfWidgetFormDateTime(),
      'created_at' => new sfWidgetFormDateTime(),
      'updated_at' => new sfWidgetFormDateTime(),
    ));

    $this->setValidators(array(
      'id'         => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'payer_id'   => new sfValidatorInteger(),
      'resiv_id'   => new sfValidatorInteger(),
      'sum'        => new sfValidatorNumber(),
      'timeplan'   => new sfValidatorDateTime(),
      'created_at' => new sfValidatorDateTime(),
      'updated_at' => new sfValidatorDateTime(),
    ));

    $this->validatorSchema->setPostValidator(
      new sfValidatorDoctrineUnique(array('model' => 'Perevod', 'column' => array('id')))
    );

    $this->widgetSchema->setNameFormat('perevod[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Perevod';
  }

}
