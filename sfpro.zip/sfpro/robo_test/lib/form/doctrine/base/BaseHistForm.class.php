<?php

/**
 * Hist form base class.
 *
 * @method Hist getObject() Returns the current form's model object
 *
 * @package    robo_test
 * @subpackage form
 * @author     MDG
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BaseHistForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'         => new sfWidgetFormInputHidden(),
      'pers_id'    => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Pers'), 'add_empty' => false)),
      'don_id'     => new sfWidgetFormInputText(),
      'sum'        => new sfWidgetFormInputText(),
      'bal_in'     => new sfWidgetFormInputText(),
      'bal_out'    => new sfWidgetFormInputText(),
      't_plan'     => new sfWidgetFormDateTime(),
      't_rel'      => new sfWidgetFormDateTime(),
      'is_rel'     => new sfWidgetFormInputCheckbox(),
      'created_at' => new sfWidgetFormDateTime(),
      'updated_at' => new sfWidgetFormDateTime(),
    ));

    $this->setValidators(array(
      'id'         => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'pers_id'    => new sfValidatorDoctrineChoice(array('model' => $this->getRelatedModelName('Pers'))),
      'don_id'     => new sfValidatorInteger(),
      'sum'        => new sfValidatorNumber(),
      'bal_in'     => new sfValidatorNumber(),
      'bal_out'    => new sfValidatorNumber(),
      't_plan'     => new sfValidatorDateTime(),
      't_rel'      => new sfValidatorDateTime(array('required' => false)),
      'is_rel'     => new sfValidatorBoolean(array('required' => false)),
      'created_at' => new sfValidatorDateTime(),
      'updated_at' => new sfValidatorDateTime(),
    ));

    $this->validatorSchema->setPostValidator(
      new sfValidatorDoctrineUnique(array('model' => 'Hist', 'column' => array('id')))
    );

    $this->widgetSchema->setNameFormat('hist[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Hist';
  }

}
