<?php

/**
 * Pers form base class.
 *
 * @method Pers getObject() Returns the current form's model object
 *
 * @package    robo_test
 * @subpackage form
 * @author     MDG
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BasePersForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'         => new sfWidgetFormInputHidden(),
      'fam'        => new sfWidgetFormInputText(),
      'name'       => new sfWidgetFormInputText(),
      'otch'       => new sfWidgetFormInputText(),
      'bal'        => new sfWidgetFormInputText(),
      'created_at' => new sfWidgetFormDateTime(),
      'updated_at' => new sfWidgetFormDateTime(),
    ));

    $this->setValidators(array(
      'id'         => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'fam'        => new sfValidatorString(array('max_length' => 255)),
      'name'       => new sfValidatorString(array('max_length' => 255)),
      'otch'       => new sfValidatorString(array('max_length' => 255)),
      'bal'        => new sfValidatorNumber(),
      'created_at' => new sfValidatorDateTime(),
      'updated_at' => new sfValidatorDateTime(),
    ));

    $this->validatorSchema->setPostValidator(
      new sfValidatorDoctrineUnique(array('model' => 'Pers', 'column' => array('id')))
    );

    $this->widgetSchema->setNameFormat('pers[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Pers';
  }

}
