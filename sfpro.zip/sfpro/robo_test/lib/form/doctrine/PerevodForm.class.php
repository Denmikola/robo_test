<?php

/**
 * Perevod form.
 *
 * @package    robo_test
 * @subpackage form
 * @author     MDG
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class PerevodForm extends BasePerevodForm
{
  public function configure()
  {
  }
}
