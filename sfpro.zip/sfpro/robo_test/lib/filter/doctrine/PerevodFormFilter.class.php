<?php

/**
 * Perevod filter form.
 *
 * @package    robo_test
 * @subpackage filter
 * @author     MDG
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class PerevodFormFilter extends BasePerevodFormFilter
{
  public function configure()
  {
  }
}
