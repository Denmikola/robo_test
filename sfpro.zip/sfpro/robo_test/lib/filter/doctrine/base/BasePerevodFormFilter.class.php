<?php

/**
 * Perevod filter form base class.
 *
 * @package    robo_test
 * @subpackage filter
 * @author     MDG
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BasePerevodFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'payer_id'   => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'resiv_id'   => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'sum'        => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'timeplan'   => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
      'created_at' => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
      'updated_at' => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
    ));

    $this->setValidators(array(
      'payer_id'   => new sfValidatorSchemaFilter('text', new sfValidatorInteger(array('required' => false))),
      'resiv_id'   => new sfValidatorSchemaFilter('text', new sfValidatorInteger(array('required' => false))),
      'sum'        => new sfValidatorSchemaFilter('text', new sfValidatorNumber(array('required' => false))),
      'timeplan'   => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
      'created_at' => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
      'updated_at' => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
    ));

    $this->widgetSchema->setNameFormat('perevod_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Perevod';
  }

  public function getFields()
  {
    return array(
      'id'         => 'Number',
      'payer_id'   => 'Number',
      'resiv_id'   => 'Number',
      'sum'        => 'Number',
      'timeplan'   => 'Date',
      'created_at' => 'Date',
      'updated_at' => 'Date',
    );
  }
}
